/** Automatically generated file. DO NOT MODIFY */
package cydiasubstrate.hooktools;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}